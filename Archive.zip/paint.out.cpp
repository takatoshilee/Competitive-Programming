#include <bits/stdc++.h>

using namespace std;

int main() {
    int array[4], min, max;
    
    for(int i = 0; i < 4; i++) {
		cin >> array[i];
	}
	
	min = array[0];
	max = array [0];
	
	for(int i = 0; i < 4; i++) {
		if(array[i] < min) {
			min = array[i];
		}
		if(array[i] > max) {
			max = array[i];
		}
	}
	cout << max - min;
}
